package com.example.testservlet;

import sun.misc.BASE64Encoder;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;


@WebServlet(name = "download", value = "/download")
public class DownLoadServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String realPath = getServletContext().getRealPath("/最新激活码.txt");
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(realPath));
        resp.setHeader("content-Type","application/octet-stream");
        resp.setHeader("content-Disposition","attachment;filename=最新激活码.txt");
        ServletOutputStream os = resp.getOutputStream();
        byte[] arr = new byte[1024];

        while (bis.read(arr) != -1){
            os.write(arr,0,bis.read(arr));
        }
        bis.close();

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
